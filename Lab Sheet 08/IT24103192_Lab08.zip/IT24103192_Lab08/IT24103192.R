setwd("C:\\Users\\User\\Downloads\\IT24103192_Lab08")
data<-read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)

##Question 01
#compute mean of dataset
popmean<-mean(data$Weight.kg.)
#compute standard deviation of dataset
popsd<-sd(data$Weight.kg.)

#Question 02
samples<-c()
n<-c()

for (i in 1:25) {
  s<-sample(data$Weight.kg.,6,replace = TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))  
}

colnames(samples)=n

s.means<-apply(samples,2,mean)
s.sd<-apply(samples,2,sd)

##Question 03
#compute mean of sample
samplemean<-mean(s.means)
#compute standard deviation of sample
samplesd<-sd(s.means)

popmean
samplemean

truesd<-popsd/sqrt(6)
truesd
samplesd