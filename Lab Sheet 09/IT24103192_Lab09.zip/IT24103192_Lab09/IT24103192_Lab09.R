setwd("C:\\Users\\User\\Downloads\\IT24103192_Lab09")
# mean = 45
# sd = 2
# n = 25

y <- rnorm(25,mean=45,sd=2)

# significant level = 0.05

t.test(y, mu=46,alternative = "less")