setwd("C:/Users/User/Downloads/IT24103192_Lab07")

# Question 01
# P(X<=25)-P(X<=10)
punif(10,min=0,max=40,lower.tail=TRUE) - punif(25,min=0,max=40,lower.tail=TRUE)

# Question 02
# P(X<=2)
pexp(2,rate = 0.33,lower.tail = TRUE)

# Question 03
# Part 1
# 1-P(X<=130) or P(X>130)
1-pnorm(130,mean = 100,sd = 15,lower.tail = TRUE)

# Part 2
# P(X<=x)=0.95
qnorm(0.95,mean = 100,sd = 15)
